require("dotenv").config();
const {
  Client, GatewayIntentBits, PermissionFlagsBits, ChannelType,
  SlashCommandBuilder, REST, Routes, EmbedBuilder
} = require("discord.js");

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers]
});

const roles = [
  ["👑 R5", 0xF1C40F],
  ["⚔️ R4", 0xE74C3C],
  ["🛡️ War Coordinator", 0x3498DB],
  ["📢 Diplomat", 0x9B59B6],
  ["⭐ Veteran", 0xF39C12],
  ["🔥 Active Member", 0x2ECC71],
  ["🌱 Recruit", 0x95A5A6]
];

const structure = {
  "📌 START HERE": [
    ["👋・welcome", "Welcome to PIRU. Read this first."],
    ["📜・alliance-rules", "Alliance rules and expectations."],
    ["📢・announcements", "Official alliance announcements."],
    ["📅・events", "Upcoming Dark War events."],
    ["🎁・rewards", "Rewards, giveaways and recognition."]
  ],
  "💬 COMMUNITY": [
    ["💬・general-chat", "Everyday alliance conversation."],
    ["😂・memes", "Memes and funny stuff."],
    ["📸・screenshots", "Game screenshots and accomplishments."],
    ["🎮・dark-war-chat", "Dark War discussion."],
    ["❓・questions", "Questions and help."]
  ],
  "⚔️ WAR ROOM": [
    ["⚔️・war-announcements", "War status and major orders."],
    ["🗺️・battle-plans", "Battle plans and formations."],
    ["🎯・targets", "Target assignments."],
    ["🛡️・defense-orders", "Defense assignments."],
    ["🚨・war-alerts", "Urgent war alerts."],
    ["📊・war-results", "After-action results."]
  ],
  "👑 COMMAND": [
    ["🔒・r5-command", "Private R5 command room."],
    ["🔒・r4-command", "Private R4 command room."],
    ["🔒・war-strategy", "Officer strategy room."],
    ["🔒・member-management", "Roster and activity management."],
    ["🔒・diplomacy", "Diplomacy and external relations."]
  ],
  "📈 ALLIANCE DEVELOPMENT": [
    ["📊・power-check", "Power checks and growth goals."],
    ["🏆・leaderboards", "Alliance rankings and recognition."],
    ["📋・member-activity", "Activity and participation."],
    ["💰・resource-coordination", "Resource coordination."],
    ["📚・guides", "Builds, guides and tips."]
  ]
};

async function setupGuild(guild) {
  const everyone = guild.roles.everyone;
  const roleMap = {};
  for (const [name, color] of roles) {
    let role = guild.roles.cache.find(r => r.name === name);
    if (!role) role = await guild.roles.create({name, color, reason: "PIRU alliance setup"});
    roleMap[name] = role;
  }

  const r5 = roleMap["👑 R5"];
  const r4 = roleMap["⚔️ R4"];
  const war = roleMap["🛡️ War Coordinator"];
  const dip = roleMap["📢 Diplomat"];

  for (const [catName, channels] of Object.entries(structure)) {
    let cat = guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name === catName);
    if (!cat) cat = await guild.channels.create({name: catName, type: ChannelType.GuildCategory});
    for (const [name, topic] of channels) {
      let ch = guild.channels.cache.find(c => c.parentId === cat.id && c.name === name);
      if (!ch) ch = await guild.channels.create({
        name, type: ChannelType.GuildText, parent: cat.id, topic
      });

      if (catName === "👑 COMMAND") {
        await ch.permissionOverwrites.edit(everyone, {ViewChannel: false});
        await ch.permissionOverwrites.edit(r5, {ViewChannel: true, SendMessages: true});
        await ch.permissionOverwrites.edit(r4, {ViewChannel: true, SendMessages: true});
        if (name.includes("war")) await ch.permissionOverwrites.edit(war, {ViewChannel: true, SendMessages: true});
        if (name.includes("diplomacy")) await ch.permissionOverwrites.edit(dip, {ViewChannel: true, SendMessages: true});
      }
    }
  }

  const welcome = guild.channels.cache.find(c => c.name === "👋・welcome");
  if (welcome) {
    const embed = new EmbedBuilder()
      .setTitle("🔴 WELCOME TO PIRU")
      .setDescription("Family. Loyalty. Growth. Communication.\
\
Read the rules, stay active, communicate with the alliance, and help us grow stronger together.")
      .setColor(0xC0392B);
    await welcome.send({embeds:[embed]}).catch(()=>{});
  }
}

const commands = [
  new SlashCommandBuilder().setName("setup").setDescription("Build the complete PIRU alliance Discord structure.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName("warplan").setDescription("Post a war plan.")
    .addStringOption(o=>o.setName("plan").setDescription("Battle plan").setRequired(true)),
  new SlashCommandBuilder().setName("target").setDescription("Assign a war target.")
    .addStringOption(o=>o.setName("target").setDescription("Target/player/coordinate").setRequired(true))
    .addStringOption(o=>o.setName("assigned").setDescription("Who is assigned").setRequired(true)),
  new SlashCommandBuilder().setName("alert").setDescription("Send an urgent war alert.")
    .addStringOption(o=>o.setName("message").setDescription("Alert").setRequired(true))
].map(c=>c.toJSON());

client.once("ready", async () => {
  console.log(`PIRU bot online as ${client.user.tag}`);
  const rest = new REST({version:"10"}).setToken(process.env.DISCORD_TOKEN);
  await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), {body: commands});
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === "setup") {
    await interaction.deferReply({ephemeral:true});
    await setupGuild(interaction.guild);
    return interaction.editReply("🔴 **PIRU HQ is built.** Roles, categories, channels and command permissions are configured.");
  }

  const ch = interaction.channel;
  if (interaction.commandName === "warplan") {
    const e = new EmbedBuilder().setTitle("⚔️ WAR PLAN").setDescription(interaction.options.getString("plan")).setFooter({text:`Issued by ${interaction.user.tag}`}).setColor(0xE74C3C);
    return ch.send({embeds:[e]});
  }
  if (interaction.commandName === "target") {
    const e = new EmbedBuilder().setTitle("🎯 TARGET ASSIGNMENT")
      .addFields({name:"Target",value:interaction.options.getString("target")},{name:"Assigned",value:interaction.options.getString("assigned")})
      .setFooter({text:`Issued by ${interaction.user.tag}`}).setColor(0xE74C3C);
    return ch.send({embeds:[e]});
  }
  if (interaction.commandName === "alert") {
    const e = new EmbedBuilder().setTitle("🚨 WAR ALERT").setDescription(interaction.options.getString("message")).setColor(0xE74C3C);
    return ch.send({content:"@everyone",embeds:[e]});
  }
});

client.login(process.env.DISCORD_TOKEN);
