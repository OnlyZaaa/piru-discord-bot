# 🔴 PIRU Alliance Bot

A self-hosted Discord bot for a Dark War alliance command center.

## What it does
- `/setup` builds the PIRU server structure
- Creates R5/R4/War Coordinator/Diplomat/Veteran/Active Member/Recruit roles
- Creates public, community, war-room, command and development channels
- Locks COMMAND channels to officers
- `/warplan` posts a formatted war plan
- `/target` posts a target assignment
- `/alert` posts an urgent war alert

## Requirements
- Node.js 18+
- A Discord server where you have Administrator permission
- A Discord application/bot token

## Install
1. Install Node.js.
2. Create a folder and extract this project.
3. Run:
   npm install
4. Copy `.env.example` to `.env`.
5. Put your bot token and application/client ID in `.env`.
6. Run:
   npm start

## Discord setup
Create an application in the Discord Developer Portal, add a bot, and use OAuth2 URL Generator with:
- Scopes: `bot`, `applications.commands`
- Permissions: Administrator (simplest for the one-command setup)

Then invite the generated URL to your server.

IMPORTANT: Never share your bot token with anyone. If it is exposed, regenerate it in the Developer Portal.

## First run
After the bot is online, type:
`/setup`

Then assign yourself the R5 role. Keep the bot's role above the roles it needs to manage.
